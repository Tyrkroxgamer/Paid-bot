#!/usr/bin/env bash
set -u
if [ "$(id -u)" -ne 0 ]; then echo "Run as root."; exit 1; fi
VM="${1:-}"
if [ -z "$VM" ]; then echo "Usage: $0 <vm-name>"; exit 2; fi
virsh -c qemu:///system net-autostart default >/dev/null 2>&1 || true
virsh -c qemu:///system net-start default >/dev/null 2>&1 || true
virsh -c qemu:///system domstate "$VM" 2>/dev/null || { echo "VM not found: $VM"; exit 3; }
STATE="$(virsh -c qemu:///system domstate "$VM" 2>/dev/null | tr '[:upper:]' '[:lower:]' | tr -d '\r')"
if [ "$STATE" != "running" ]; then virsh -c qemu:///system start "$VM" || exit 4; sleep 3; fi
virsh -c qemu:///system domiflist "$VM" || true
virsh -c qemu:///system net-dhcp-leases default || true

#!/usr/bin/env bash
set -u
BASE=/opt/zylexnode
printf '== ZylexNode preflight ==\n'
for cmd in python3 systemctl virsh qemu-img; do
  printf '%-12s' "$cmd"
  command -v "$cmd" || true
done
printf '\n== Bot files ==\n'
ls -lh "$BASE/bot.py" "$BASE/.env" "$BASE/requirements.txt" 2>/dev/null || true
printf '\n== Database setting (secret-free) ==\n'
if [ -f "$BASE/.env" ]; then
  grep -E '^[[:space:]]*VPS_DB_PATH=' "$BASE/.env" || echo 'VPS_DB_PATH not set; bot default path applies.'
fi
printf '\n== KVM ==\n'
test -e /dev/kvm && echo '/dev/kvm present' || echo '/dev/kvm missing'
virsh -c qemu:///system list --all 2>&1 | head -60 || true
printf '\n== Service ==\n'
systemctl status voxelcloud-bot --no-pager -l 2>&1 | head -60 || true

#!/usr/bin/env bash
set -euo pipefail
BASE=/opt/zylexnode
SRC="$(cd "$(dirname "$0")/.." && pwd)"
STAMP="$(date +%Y%m%d-%H%M%S)"

if [ "$(id -u)" -ne 0 ]; then echo "Run this installer as root."; exit 1; fi

export DEBIAN_FRONTEND=noninteractive
apt-get update -y
apt-get install -y python3 python3-pip python3-venv curl ca-certificates util-linux procps iproute2 openssh-client openssh-server unzip sqlite3 qemu-kvm qemu-utils libvirt-clients libvirt-daemon-system virtinst dnsmasq-base

if [ -d "$BASE" ] && [ -f "$BASE/bot.py" ]; then
  cp -a "$BASE" "${BASE}.backup-${STAMP}"
  echo "Backup: ${BASE}.backup-${STAMP}"
fi

mkdir -p "$BASE"
cp -a "$SRC/." "$BASE/"
rm -rf "$BASE/__pycache__"

if [ ! -f "$BASE/.env" ]; then cp "$BASE/.env.example" "$BASE/.env"; fi
chmod 600 "$BASE/.env"

python3 -m venv "$BASE/.venv"
"$BASE/.venv/bin/python" -m pip install --upgrade pip wheel setuptools
"$BASE/.venv/bin/pip" install -r "$BASE/requirements.txt"

bash "$BASE/scripts/kvm-doctor.sh" || true

install -m 0644 "$BASE/systemd/voxelcloud-bot.service" /etc/systemd/system/voxelcloud-bot.service
systemctl daemon-reload
systemctl enable voxelcloud-bot

"$BASE/.venv/bin/python" -m py_compile "$BASE/bot.py"

echo
echo "ZylexNode bundle installed to $BASE"
echo "1) Edit: nano $BASE/.env"
echo "2) Check: bash $BASE/scripts/doctor.sh"
echo "3) KVM:   bash $BASE/scripts/kvm-doctor.sh"
echo "4) Start: systemctl restart voxelcloud-bot"
echo "5) Logs:  journalctl -u voxelcloud-bot -n 100 --no-pager -o cat"

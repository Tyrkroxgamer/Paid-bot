#!/usr/bin/env bash
# Non-destructive diagnostics for LXC/Incus project and libvirt KVM issues.
set +e
NAME="${1:-}"
printf '\n===== HOST / BOT =====\n'
uname -a
systemctl is-active voxelcloud-bot 2>/dev/null
systemctl is-enabled voxelcloud-bot 2>/dev/null
printf '\n===== LXC / INCUS VERSION =====\n'
if command -v incus >/dev/null 2>&1; then incus version; elif command -v lxc >/dev/null 2>&1; then lxc version; else echo 'LXC/Incus CLI not found'; fi
printf '\n===== LXC PROJECTS =====\n'
if command -v incus >/dev/null 2>&1; then incus project list; elif command -v lxc >/dev/null 2>&1; then lxc project list; fi
printf '\n===== LXC INSTANCES ALL PROJECTS =====\n'
if command -v incus >/dev/null 2>&1; then incus list --all-projects; elif command -v lxc >/dev/null 2>&1; then lxc list --all-projects; fi
if [ -n "$NAME" ]; then
  printf '\n===== SEARCH LXC INSTANCE: %s =====\n' "$NAME"
  if command -v incus >/dev/null 2>&1; then incus list --all-projects | grep -F -- "$NAME" || true; elif command -v lxc >/dev/null 2>&1; then lxc list --all-projects | grep -F -- "$NAME" || true; fi
fi
printf '\n===== LIBVIRT SERVICES =====\n'
systemctl is-active libvirtd virtqemud virtlogd 2>/dev/null
printf '\n===== KVM DOMAINS =====\n'
virsh -c qemu:///system list --all 2>&1
printf '\n===== LIBVIRT NETWORK =====\n'
virsh -c qemu:///system net-info default 2>&1
virsh -c qemu:///system net-dhcp-leases default 2>&1
if [ -n "$NAME" ]; then
  printf '\n===== KVM DOMAIN DETAILS: %s =====\n' "$NAME"
  virsh -c qemu:///system domstate "$NAME" 2>&1
  virsh -c qemu:///system domiflist "$NAME" 2>&1
  virsh -c qemu:///system domifaddr "$NAME" --source lease 2>&1
  virsh -c qemu:///system qemu-agent-command "$NAME" '{"execute":"guest-ping"}' --timeout 5 2>&1
fi
printf '\n===== HOST CAPACITY =====\n'
free -h
df -h /var/lib/libvirt/images 2>/dev/null
printf '\n===== END (READ-ONLY) =====\n'

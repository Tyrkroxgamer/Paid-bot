#!/usr/bin/env bash
set +e
BASE=/opt/zylexnode
PY="$BASE/.venv/bin/python"
printf '\n=== ZylexNode Host Doctor ===\n'
printf 'Python: '; [ -x "$PY" ] && "$PY" --version 2>&1 || python3 --version 2>&1
printf 'Bot syntax: '; [ -x "$PY" ] && "$PY" -m py_compile "$BASE/bot.py" 2>&1 && echo OK || python3 -m py_compile "$BASE/bot.py" 2>&1 && echo OK || echo FAILED
printf 'discord.py: '; [ -x "$PY" ] && "$PY" -c 'import discord; print(discord.__version__)' 2>/dev/null || python3 -c 'import discord; print(discord.__version__)' 2>/dev/null || echo NOT INSTALLED
printf '.env permissions: '; stat -c '%a %n' "$BASE/.env" 2>/dev/null || true
printf 'virsh: '; command -v virsh || true
printf 'virt-install: '; command -v virt-install || true
printf 'qemu-img: '; command -v qemu-img || true
printf '/dev/kvm: '; test -e /dev/kvm && echo YES || echo NO
printf '\n=== RAM ===\n'; free -h
printf '\n=== Disk ===\n'; df -h / "$BASE" /var/lib/libvirt 2>/dev/null || df -h /
printf '\n=== Libvirt ===\n'; systemctl is-active libvirtd 2>/dev/null || systemctl is-active virtqemud 2>/dev/null || true
printf '\n=== KVM network ===\n'; virsh -c qemu:///system net-info default 2>&1 || true
printf '\n=== KVM network XML ===\n'; virsh -c qemu:///system net-dumpxml default 2>&1 | head -80 || true
printf '\n=== KVM list ===\n'; virsh -c qemu:///system list --all 2>&1 | head -80 || true
printf '\n=== Cloudflare binary ===\n'; cloudflared --version 2>/dev/null || echo 'cloudflared not installed (optional)'
printf '\n=== systemd bot ===\n'; systemctl is-enabled voxelcloud-bot 2>/dev/null || true; systemctl is-active voxelcloud-bot 2>/dev/null || true
printf '\n=== Result ===\n'
if [ -e /dev/kvm ] && command -v virsh >/dev/null && command -v virt-install >/dev/null && command -v qemu-img >/dev/null; then
  echo 'KVM prerequisites: READY'
else
  echo 'KVM prerequisites: NOT READY — fix the missing items above.'
fi

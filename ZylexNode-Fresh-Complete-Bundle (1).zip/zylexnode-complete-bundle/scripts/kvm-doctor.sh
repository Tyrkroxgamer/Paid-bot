#!/usr/bin/env bash
set -u

log(){ echo "[KVM-DOCTOR] $*"; }
fail=0

if [ "$(id -u)" -ne 0 ]; then echo "Run as root."; exit 1; fi

export DEBIAN_FRONTEND=noninteractive
if command -v apt-get >/dev/null 2>&1; then
  apt-get update -y >/dev/null 2>&1 || true
  apt-get install -y qemu-kvm qemu-utils libvirt-daemon-system libvirt-clients virtinst dnsmasq-base iproute2 curl ca-certificates >/dev/null 2>&1 || true
fi

for svc in libvirtd virtqemud virtlogd; do
  systemctl enable --now "$svc" >/dev/null 2>&1 || true
done

modprobe kvm >/dev/null 2>&1 || true
modprobe kvm_intel >/dev/null 2>&1 || modprobe kvm_amd >/dev/null 2>&1 || true

sysctl -w net.ipv4.ip_forward=1 >/dev/null 2>&1 || true
cat >/etc/sysctl.d/99-voxelcloud-kvm.conf <<'EOF'
net.ipv4.ip_forward=1
net.ipv4.conf.all.forwarding=1
net.ipv4.conf.default.forwarding=1
EOF
sysctl --system >/dev/null 2>&1 || true

if ! command -v virsh >/dev/null 2>&1; then
  echo "FAIL: virsh missing"; exit 2
fi

CONN=qemu:///system
if ! virsh -c "$CONN" net-info default >/dev/null 2>&1; then
  cat >/tmp/voxelcloud-default-network.xml <<'EOF'
<network>
  <name>default</name>
  <forward mode='nat'/>
  <bridge name='virbr0' stp='on' delay='0'/>
  <ip address='192.168.122.1' netmask='255.255.255.0'>
    <dhcp><range start='192.168.122.2' end='192.168.122.254'/></dhcp>
  </ip>
</network>
EOF
  virsh -c "$CONN" net-define /tmp/voxelcloud-default-network.xml >/dev/null 2>&1 || true
  rm -f /tmp/voxelcloud-default-network.xml
fi

virsh -c "$CONN" net-autostart default >/dev/null 2>&1 || true
virsh -c "$CONN" net-start default >/dev/null 2>&1 || true

log "KVM device: $(test -e /dev/kvm && echo OK || echo MISSING)"
log "virsh: $(command -v virsh || echo MISSING)"
log "virt-install: $(command -v virt-install || echo MISSING)"
log "qemu-img: $(command -v qemu-img || echo MISSING)"
log "libvirt default network:"
virsh -c "$CONN" net-info default 2>&1 || fail=1
log "network XML:"
virsh -c "$CONN" net-dumpxml default 2>&1 | sed -n '1,80p' || fail=1
log "IP forwarding: $(sysctl -n net.ipv4.ip_forward 2>/dev/null || echo unknown)"
log "bridge:"
ip -br link show virbr0 2>/dev/null || true

if [ ! -e /dev/kvm ]; then
  echo "FAIL: /dev/kvm is unavailable. If this server is itself a VM/LXC, the parent provider must expose nested KVM."
  fail=1
fi

if ! virsh -c "$CONN" net-info default 2>/dev/null | grep -qi 'Active:.*yes'; then
  echo "FAIL: libvirt default network is not active."
  fail=1
fi

if [ "$fail" -eq 0 ]; then
  log "KVM host doctor: PASS"
else
  log "KVM host doctor: CHECK FAILED - see messages above"
fi
exit "$fail"
